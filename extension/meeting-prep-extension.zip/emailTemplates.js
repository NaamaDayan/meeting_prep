/**
 * Email templates used by the Calendar prep UI.
 * Loaded as part of the MV3 content scripts (see manifest.json).
 */
(function () {
  const SUBJECT = "Prep for our upcoming meeting";

  function buildPrepQuestionsEmailBody({ senderName, questions }) {
    const safeSender = String(senderName || "").trim() || "your meeting prep agent";
    const qs =
      Array.isArray(questions) && questions.length
        ? questions.map((q) => `• ${String(q).trim()}`).filter(Boolean).join("\n")
        : "• (no questions found)";

    // Keep the body formatting mailto-friendly (use plain newlines).
    return (
      "Hi,\n" +
      `I'm ${safeSender},\n` +
      "In order to prep for our meeting, it would be great if you can answer the following questions:\n" +
      `${qs}\n` +
      "Looking forward."
    );
  }

  globalThis.MP_EMAIL_TEMPLATES = Object.assign(globalThis.MP_EMAIL_TEMPLATES || {}, {
    PREP_QUESTIONS_SUBJECT: SUBJECT,
    buildPrepQuestionsEmailBody,
  });
})();

